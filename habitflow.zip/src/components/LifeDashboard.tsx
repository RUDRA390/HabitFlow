import { UserProfile, Habit, Task } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Progress } from './ui/progress';
import { 
  Trophy, 
  Zap, 
  Target, 
  TrendingUp, 
  Shield, 
  Star, 
  Crown,
  Flame,
  Brain,
  Coins
} from 'lucide-react';
import { motion } from 'motion/react';
import { XP_PER_LEVEL } from '../lib/services';

interface LifeDashboardProps {
  profile: UserProfile | null;
  habits: Habit[];
  tasks: Task[];
}

export default function LifeDashboard({ profile, habits, tasks }: LifeDashboardProps) {
  const level = profile?.level || 1;
  const xp = profile?.xp || 0;
  const currentLevelXP = xp % XP_PER_LEVEL;
  const progress = (currentLevelXP / XP_PER_LEVEL) * 100;
  
  // Calculate Discipline Score (0-100)
  // Based on habit completion in last 7 days and task completion
  const today = new Date().toISOString().split('T')[0];
  const completedToday = habits.filter(h => h.completedDates.includes(today)).length;
  const habitScore = habits.length > 0 ? (completedToday / habits.length) * 100 : 100;
  
  const completedTasks = tasks.filter(t => t.completed).length;
  const taskScore = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 100;
  
  const disciplineScore = Math.round((habitScore * 0.7) + (taskScore * 0.3));

  const stats = [
    { 
      label: 'Discipline Score', 
      value: `${disciplineScore}%`, 
      icon: Shield, 
      color: 'text-blue-500', 
      description: 'Based on your consistency' 
    },
    { 
      label: 'Focus Power', 
      value: `${profile?.totalFocusTime || 0}m`, 
      icon: Brain, 
      color: 'text-purple-500', 
      description: 'Total deep work time' 
    },
    { 
      label: 'Habit Streak', 
      value: Math.max(...habits.map(h => h.streak), 0), 
      icon: Flame, 
      color: 'text-orange-500', 
      description: 'Best current streak' 
    },
    { 
      label: 'Wealth', 
      value: profile?.coins || 0, 
      icon: Coins, 
      color: 'text-yellow-500', 
      description: 'Habit coins earned' 
    },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="p-2 bg-primary/10 rounded-xl">
              <Crown className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tighter text-gradient">
                {profile?.title} {profile?.displayName?.split(' ')[0]}
              </h1>
              <p className="text-muted-foreground font-medium">Level {level} Life Progression</p>
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass p-6 rounded-3xl flex items-center gap-6 shadow-2xl border-primary/10"
        >
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="40"
                cy="40"
                r="36"
                stroke="currentColor"
                strokeWidth="6"
                fill="transparent"
                className="text-white/5"
              />
              <motion.circle
                cx="40"
                cy="40"
                r="36"
                stroke="currentColor"
                strokeWidth="6"
                fill="transparent"
                strokeDasharray={226}
                initial={{ strokeDashoffset: 226 }}
                animate={{ strokeDashoffset: 226 - (226 * progress) / 100 }}
                className="text-primary"
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute text-xl font-black">{level}</span>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-black uppercase tracking-widest text-muted-foreground">XP Progress</span>
              <span className="text-xs font-black">{currentLevelXP} / {XP_PER_LEVEL}</span>
            </div>
            <div className="w-48 h-2 bg-white/5 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-primary shadow-[0_0_10px_rgba(var(--primary),0.5)]"
              />
            </div>
            <p className="text-[10px] font-bold text-primary mt-2 uppercase tracking-widest">
              {XP_PER_LEVEL - currentLevelXP} XP to Level {level + 1}
            </p>
          </div>
        </motion.div>
      </header>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="glass border-none shadow-xl card-hover overflow-hidden relative group">
              <div className={`absolute -right-4 -top-4 opacity-10 group-hover:opacity-20 transition-opacity`}>
                <stat.icon className="w-24 h-24" />
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                  {stat.label}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-black tracking-tighter">{stat.value}</div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2 glass border-none shadow-2xl rounded-3xl overflow-hidden bg-linear-to-br from-primary/10 to-transparent">
          <CardHeader>
            <CardTitle className="text-2xl font-black tracking-tight flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-primary" />
              Weekly Life Progress
            </CardTitle>
            <CardDescription className="font-medium">Your journey towards your future self</CardDescription>
          </CardHeader>
          <CardContent className="h-64 flex items-end justify-between gap-2 px-8 pb-8">
            {/* Simple visual bar chart for the week */}
            {[6, 5, 4, 3, 2, 1, 0].map((daysAgo) => {
              const date = new Date();
              date.setDate(date.getDate() - daysAgo);
              const dateStr = date.toISOString().split('T')[0];
              const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
              
              const dayCompleted = habits.filter(h => h.completedDates.includes(dateStr)).length;
              const dayTotal = habits.length || 1;
              const dayHeight = (dayCompleted / dayTotal) * 100;
              
              return (
                <div key={daysAgo} className="flex-1 flex flex-col items-center gap-3 group">
                  <div className="w-full bg-white/5 rounded-2xl relative h-48 overflow-hidden">
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${dayHeight}%` }}
                      className={`absolute bottom-0 w-full rounded-t-xl transition-all ${
                        dayHeight > 80 ? 'bg-primary' : 
                        dayHeight > 50 ? 'bg-blue-500' : 
                        'bg-muted-foreground/20'
                      }`}
                    />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground group-hover:text-primary transition-colors">
                    {dayName}
                  </span>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card className="glass border-none shadow-2xl rounded-3xl overflow-hidden bg-linear-to-br from-purple-600/10 to-transparent">
          <CardHeader>
            <CardTitle className="text-2xl font-black tracking-tight flex items-center gap-2">
              <Zap className="w-6 h-6 text-purple-500" />
              Active Buffs
            </CardTitle>
            <CardDescription className="font-medium">Current active modifiers</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
              <div className="p-2 bg-orange-500/20 rounded-xl">
                <Flame className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <p className="font-bold">Streak Bonus</p>
                <p className="text-xs text-muted-foreground">1.2x XP Multiplier active</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
              <div className="p-2 bg-blue-500/20 rounded-xl">
                <Shield className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="font-bold">Streak Freezes</p>
                <p className="text-xs text-muted-foreground">{profile?.streakFreezes || 0} Available</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5 opacity-50">
              <div className="p-2 bg-muted rounded-xl">
                <Star className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-bold text-muted-foreground">Premium Buff</p>
                <p className="text-xs text-muted-foreground">Unlock for 2x XP & Coins</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
